using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using u22685759_HW03_Backend.Models;

namespace u22685759_HW03_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer")]
    public class WatchlistController : ControllerBase
    {
        private readonly AppDbContext _context;

        public WatchlistController(AppDbContext context)
        {
            _context = context;
        }

        private string? GetUserId() =>
            User.FindFirstValue(ClaimTypes.NameIdentifier) ??
            User.FindFirstValue("sub");

        [HttpGet]
        public async Task<IActionResult> GetWatchlist()
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized();

            var items = await _context.Watchlist
                .Where(w => w.UserId == userId)
                .ToListAsync();

            if (!items.Any()) return NotFound("Watchlist is empty.");
            return Ok(items);
        }

        [HttpPost]
        public async Task<IActionResult> AddToWatchlist([FromBody] Watchlist movie)
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized();

            var exists = await _context.Watchlist
                .AnyAsync(w => w.UserId == userId && w.ImdbId == movie.ImdbId);

            if (exists) return Conflict("Movie already in watchlist.");

            var newItem = new Watchlist
            {
                UserId = userId,
                ImdbId = movie.ImdbId,
                Title = movie.Title,
                Year = movie.Year,
                Poster = movie.Poster,
                Actors = movie.Actors,
                Genre = movie.Genre,
                AddedAt = DateTime.UtcNow
            };

            _context.Watchlist.Add(newItem);
            await _context.SaveChangesAsync();
            return Ok(newItem);
        }

       [HttpDelete("{id}")]
public async Task<IActionResult> RemoveFromWatchlist(int id)
{
    var userId = GetUserId();
    if (userId == null)
        return Unauthorized();

    var item = await _context.Watchlist
        .FirstOrDefaultAsync(w => w.UserId == userId && w.Id == id);

    if (item == null)
        return NotFound("Movie not found in watchlist.");

    _context.Watchlist.Remove(item);

    await _context.SaveChangesAsync();

    return Ok("Removed from watchlist.");
}
    }
}
