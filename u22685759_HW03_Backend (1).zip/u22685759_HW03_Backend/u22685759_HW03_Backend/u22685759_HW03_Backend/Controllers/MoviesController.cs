using Microsoft.AspNetCore.Mvc;
using u22685759_HW03_Backend.Service;

namespace u22685759_HW03_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly OmdbService _omdbService;

        public MoviesController(OmdbService omdbService)
        {
            _omdbService = omdbService;
        }

        [HttpGet("search")]
        public async Task<IActionResult> Search([FromQuery] string t)
        {
            if (string.IsNullOrWhiteSpace(t))
                return BadRequest("Search term is required.");

            var result = await _omdbService.SearchMoviesAsync(t);
            return Ok(result);
        }

        [HttpGet("details")]
        public async Task<IActionResult> GetDetails([FromQuery] string t)
        {
            if (string.IsNullOrWhiteSpace(t))
                return BadRequest("Title is required.");

            var result = await _omdbService.GetMovieByTitleAsync(t);
            return Ok(result);
        }
    }
}
