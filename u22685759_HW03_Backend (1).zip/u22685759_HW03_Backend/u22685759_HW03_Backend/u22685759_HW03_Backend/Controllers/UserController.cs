﻿using u22685759_HW03_Backend.Models;
using u22685759_HW03_Backend.VModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace u22685759_HW03_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : Controller
    {
        private readonly UserManager<User> _userManager;
        private readonly IUserClaimsPrincipalFactory<User> _claimsPrincipalFactory;
        private readonly IConfiguration _configuration;

        private readonly IAuthenticationService _authenticationService;
        private readonly ILogger<UserController> _logger;

        public UserController(UserManager<User> userManager, IUserClaimsPrincipalFactory<User> claimsPrincipalFactory, IConfiguration configuration, ILogger<UserController> logger, IAuthenticationService authenticationService)
        {
            _userManager = userManager;
            _claimsPrincipalFactory = claimsPrincipalFactory;
            _logger = logger;
            _authenticationService = authenticationService;
            _configuration = configuration;
        }

        [HttpPost]
        [Route("Register")]
        public async Task<IActionResult> Register(UserRegVModel uvm)
        {
            var registerUser = await _userManager.FindByEmailAsync(uvm.Emailaddress);

            if (registerUser == null)
            {
                registerUser = new User
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = uvm.FirstName,
                    UserName = uvm.Emailaddress,
                    Email = uvm.Emailaddress,
                };

                var result = await _userManager.CreateAsync(registerUser, uvm.Password);

                if (!result.Succeeded)
                {
                    return BadRequest(result.Errors);
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

            }
            else
            {
                return Forbid("Account already exists.");
            }

            return Ok();
        }

        [HttpPost]
        [Route("Login")]
        public async Task<ActionResult> Login(UserVModel uvm)
        {
            var loginUser = await _userManager.FindByNameAsync(uvm.Emailaddress);

            if (loginUser != null && await _userManager.CheckPasswordAsync(loginUser, uvm.Password))

            {
                try
                {
                    return GenerateJWTToken(loginUser);
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
                }
            }
            else
            {
                return NotFound("Does not exist");
            }
        }

        private ActionResult GenerateJWTToken(User user)
        {
            var claims = new[]
            {
        new Claim(JwtRegisteredClaimNames.Sub, user.Id),
        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        new Claim(JwtRegisteredClaimNames.UniqueName, user.UserName)
    };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Tokens:Key"]));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _configuration["Tokens:Issuer"],
                _configuration["Tokens:Audience"],
                claims,
                signingCredentials: credentials,
                expires: DateTime.UtcNow.AddHours(3)
            );

            return Created("", new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                user = user.UserName
            });
        }
    }
}
