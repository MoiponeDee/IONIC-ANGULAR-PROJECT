using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using u22685759_HW03_Backend.Models;

namespace u22685759_HW03_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer")]
    public class WatchedController : ControllerBase
    {
        private readonly AppDbContext _context;

        public WatchedController(AppDbContext context)
        {
            _context = context;
        }

        private string? GetUserId() =>
            User.FindFirstValue(ClaimTypes.NameIdentifier) ??
            User.FindFirstValue("sub");

        [HttpGet]
        public async Task<IActionResult> GetWatchedList()
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized();

            var items = await _context.Watched
                .Where(w => w.UserId == userId)
                .ToListAsync();

            if (!items.Any()) return NotFound("Watched list is empty.");
            return Ok(items);
        }

        [HttpPost]
        public async Task<IActionResult> MarkAsWatched([FromBody] Watchlist movie)
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized();

            // Remove from watchlist if present
            var watchlistItem = await _context.Watchlist
                .FirstOrDefaultAsync(w => w.UserId == userId && w.ImdbId == movie.ImdbId);
            if (watchlistItem != null)
            {
                _context.Watchlist.Remove(watchlistItem);
            }

            // Increment if already in watched list, otherwise add
            var existing = await _context.Watched
                .FirstOrDefaultAsync(w => w.UserId == userId && w.ImdbId == movie.ImdbId);

            if (existing != null)
            {
                existing.TimesWatched++;
                existing.WatchedAt = DateTime.UtcNow;
                await _context.SaveChangesAsync();
                return Ok(existing);
            }
            else
            {
                var newItem = new Watched
                {
                    UserId = userId,
                    ImdbId = movie.ImdbId,
                    Title = movie.Title,
                    Year = movie.Year,
                    Poster = movie.Poster,
                    Actors = movie.Actors,
                    Genre = movie.Genre,
                    TimesWatched = 1,
                    AddedAt = DateTime.UtcNow,
                    WatchedAt = DateTime.UtcNow
                };
                _context.Watched.Add(newItem);
                await _context.SaveChangesAsync();
                return Ok(newItem);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> IncrementTimesWatched(int id)
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized();

            var item = await _context.Watched
                .FirstOrDefaultAsync(w => w.Id == id && w.UserId == userId);

            if (item == null) return NotFound("Watched item not found.");

            item.TimesWatched++;
            item.WatchedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();
            return Ok(item);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> RemoveFromWatched(int id)
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized();

            var item = await _context.Watched
                .FirstOrDefaultAsync(w => w.Id == id && w.UserId == userId);

            if (item == null) return NotFound("Watched item not found.");

            _context.Watched.Remove(item);
            await _context.SaveChangesAsync();
            return Ok("Removed from watched list.");
        }

        [HttpPost("reset/{id}")]
        public async Task<IActionResult> ResetTimesWatched(int id)
        {
            var userId = GetUserId();
            if (userId == null) return Unauthorized();

            var item = await _context.Watched
                .FirstOrDefaultAsync(w => w.Id == id && w.UserId == userId);

            if (item == null) return NotFound("Watched item not found.");

            
            _context.Watched.Remove(item);
            _context.Watchlist.Add(new Watchlist
            {
                UserId = userId,
                ImdbId = item.ImdbId,
                Title = item.Title,
                Year = item.Year,
                Poster = item.Poster,
                Actors = item.Actors,
                Genre = item.Genre,
                AddedAt = DateTime.UtcNow
            });

            await _context.SaveChangesAsync();
            return Ok("Reset and moved back to watchlist.");
        }
    }
}
