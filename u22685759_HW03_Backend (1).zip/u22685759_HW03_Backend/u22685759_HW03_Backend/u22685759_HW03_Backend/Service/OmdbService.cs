﻿using System.Text.Json;

namespace u22685759_HW03_Backend.Service
{
    public class OmdbService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;
        private readonly string _baseUrl;

        public OmdbService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _apiKey = configuration["Omdb:ApiKey"];
            _baseUrl = configuration["Omdb:BaseUrl"];
        }

        public async Task<JsonElement> SearchMoviesAsync(string title)
        {
            var url = $"{_baseUrl}/?s={Uri.EscapeDataString(title)}&apikey={_apiKey}";
            var response = await _httpClient.GetStringAsync(url);
            return JsonSerializer.Deserialize<JsonElement>(response);
        }

        public async Task<JsonElement> GetMovieByTitleAsync(string title)
        {
            var url = $"{_baseUrl}/?t={Uri.EscapeDataString(title)}&apikey={_apiKey}";
            var response = await _httpClient.GetStringAsync(url);
            return JsonSerializer.Deserialize<JsonElement>(response);
        }
    }
}