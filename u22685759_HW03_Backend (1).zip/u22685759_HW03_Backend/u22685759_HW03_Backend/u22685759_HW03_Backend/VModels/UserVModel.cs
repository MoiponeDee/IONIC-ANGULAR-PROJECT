﻿using System.ComponentModel.DataAnnotations;

namespace u22685759_HW03_Backend.VModels
{
    public class UserVModel
    {
        public string Emailaddress { get; set; }
        public string Password { get; set; }
    }
}
