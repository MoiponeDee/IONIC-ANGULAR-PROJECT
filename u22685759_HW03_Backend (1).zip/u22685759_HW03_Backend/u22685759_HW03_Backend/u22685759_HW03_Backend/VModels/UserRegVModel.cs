﻿using System.ComponentModel.DataAnnotations;

namespace u22685759_HW03_Backend.VModels
{
    public class UserRegVModel
    {
        public string FirstName { get; set; }
        public string Emailaddress { get; set; }
        public string Password { get; set; }
    }
}
