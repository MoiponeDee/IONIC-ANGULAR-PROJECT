﻿using Microsoft.AspNetCore.Identity;

namespace u22685759_HW03_Backend.Models
{
    public class User: IdentityUser
    {
        public string? Name { get; set; }
    }
}
