using System.Text.Json.Serialization;

namespace u22685759_HW03_Backend.Models
{
    public class Watched
    {
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;

        [JsonIgnore]
        public User? User { get; set; }

        public string ImdbId { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Year { get; set; } = string.Empty;
        public string? Poster { get; set; }
        public string? Actors { get; set; }
        public string? Genre { get; set; }
        public DateTime AddedAt { get; set; }
        public int TimesWatched { get; set; }
        public DateTime WatchedAt { get; set; }
    }
}
