﻿using u22685759_HW03_Backend.VModels;

namespace u22685759_HW03_Backend.Models
{
    public interface IRepository
    {
        Task<bool> SaveChangesAsync();

        void Add<T>(T entity) where T : class;
    }
}
