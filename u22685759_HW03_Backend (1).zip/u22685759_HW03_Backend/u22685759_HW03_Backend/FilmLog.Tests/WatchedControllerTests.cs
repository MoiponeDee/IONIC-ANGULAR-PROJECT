using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using u22685759_HW03_Backend.Controllers;
using u22685759_HW03_Backend.Models;
using Xunit;

namespace FilmLog.Tests;

public class WatchedControllerTests
{
    // ─── Helpers ────────────────────────────────────────────────────────────

    /// <summary>
    /// Creates a fresh in-memory AppDbContext for each test so tests are isolated.
    /// </summary>
    private static AppDbContext CreateContext(string dbName)
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(dbName)
            .Options;
        return new AppDbContext(options);
    }

    /// <summary>
    /// Attaches a fake authenticated user (userId) to a controller so that
    /// User.FindFirstValue(...) returns the expected id.
    /// </summary>
    private static void SetUser(ControllerBase controller, string userId)
    {
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, userId),
            new Claim("sub", userId)
        };
        var identity = new ClaimsIdentity(claims, "TestAuth");
        controller.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext
            {
                User = new ClaimsPrincipal(identity)
            }
        };
    }

    // ─── GET /api/watched ────────────────────────────────────────────────────

    /// <summary>
    /// When the watched list contains items for the authenticated user,
    /// GET /api/watched must return HTTP 200 OK with the items.
    /// </summary>
    [Fact]
    public async Task GetWatchedList_ReturnsOk_WhenItemsExist()
    {
        // Arrange
        using var context = CreateContext(nameof(GetWatchedList_ReturnsOk_WhenItemsExist));
        const string userId = "user-123";

        context.Watched.Add(new Watched
        {
            UserId  = userId,
            ImdbId  = "tt1234567",
            Title   = "Inception",
            Year    = "2010",
            Poster  = "https://example.com/poster.jpg",
            Actors  = "Leonardo DiCaprio",
            Genre   = "Sci-Fi",
            TimesWatched = 2,
            AddedAt  = DateTime.UtcNow,
            WatchedAt = DateTime.UtcNow
        });
        await context.SaveChangesAsync();

        var controller = new WatchedController(context);
        SetUser(controller, userId);

        // Act
        var result = await controller.GetWatchedList();

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(StatusCodes.Status200OK, ok.StatusCode);

        var items = Assert.IsAssignableFrom<IEnumerable<Watched>>(ok.Value);
        Assert.Single(items);
    }

    /// <summary>
    /// When the watched list is empty for the authenticated user,
    /// GET /api/watched must return HTTP 404 Not Found.
    /// </summary>
    [Fact]
    public async Task GetWatchedList_ReturnsNotFound_WhenEmpty()
    {
        // Arrange
        using var context = CreateContext(nameof(GetWatchedList_ReturnsNotFound_WhenEmpty));
        const string userId = "user-456";

        var controller = new WatchedController(context);
        SetUser(controller, userId);

        // Act
        var result = await controller.GetWatchedList();

        // Assert
        var notFound = Assert.IsType<NotFoundObjectResult>(result);
        Assert.Equal(StatusCodes.Status404NotFound, notFound.StatusCode);
    }

    // ─── GET /api/watchlist ──────────────────────────────────────────────────

    /// <summary>
    /// When the watchlist contains items, GET /api/watchlist returns HTTP 200 OK.
    /// </summary>
    [Fact]
    public async Task GetWatchlist_ReturnsOk_WhenItemsExist()
    {
        // Arrange
        using var context = CreateContext(nameof(GetWatchlist_ReturnsOk_WhenItemsExist));
        const string userId = "user-789";

        context.Watchlist.Add(new Watchlist
        {
            UserId  = userId,
            ImdbId  = "tt9876543",
            Title   = "Interstellar",
            Year    = "2014",
            Poster  = "https://example.com/poster2.jpg",
            Actors  = "Matthew McConaughey",
            Genre   = "Sci-Fi",
            AddedAt = DateTime.UtcNow
        });
        await context.SaveChangesAsync();

        var controller = new WatchlistController(context);
        SetUser(controller, userId);

        // Act
        var result = await controller.GetWatchlist();

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(StatusCodes.Status200OK, ok.StatusCode);

        var items = Assert.IsAssignableFrom<IEnumerable<Watchlist>>(ok.Value);
        Assert.Single(items);
    }

    /// <summary>
    /// When the watchlist is empty, GET /api/watchlist returns HTTP 404 Not Found.
    /// </summary>
    [Fact]
    public async Task GetWatchlist_ReturnsNotFound_WhenEmpty()
    {
        // Arrange
        using var context = CreateContext(nameof(GetWatchlist_ReturnsNotFound_WhenEmpty));
        const string userId = "user-000";

        var controller = new WatchlistController(context);
        SetUser(controller, userId);

        // Act
        var result = await controller.GetWatchlist();

        // Assert
        var notFound = Assert.IsType<NotFoundObjectResult>(result);
        Assert.Equal(StatusCodes.Status404NotFound, notFound.StatusCode);
    }
}
