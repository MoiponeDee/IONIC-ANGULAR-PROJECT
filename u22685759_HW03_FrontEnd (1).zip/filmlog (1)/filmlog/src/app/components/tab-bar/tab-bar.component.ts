import { Component, NgZone } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { IonIcon } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { searchOutline, bookmarkOutline, checkmarkDoneOutline, barChartOutline, logOutOutline } from 'ionicons/icons';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-tab-bar',
  templateUrl: './tab-bar.component.html',
  styleUrls: ['./tab-bar.component.scss'],
  imports: [CommonModule, IonIcon]
})
export class TabBarComponent {
  currentUrl = '';

  constructor(private router: Router, private ngZone: NgZone, private authService: AuthService) {
    addIcons({ searchOutline, bookmarkOutline, checkmarkDoneOutline, barChartOutline, logOutOutline });
    this.currentUrl = this.router.url;
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.ngZone.run(() => {
          this.currentUrl = event.urlAfterRedirects;
        });
      }
    });
  }

  go(page: string) {
    this.ngZone.run(() => {
      this.router.navigateByUrl('/' + page);
    });
  }

  isActive(page: string): boolean {
    return this.currentUrl.startsWith('/' + page);
  }

  logout() {
    this.authService.logout();
    this.ngZone.run(() => {
      this.router.navigateByUrl('/login', { replaceUrl: true });
    });
  }
}