import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonSearchbar, IonButton, IonGrid, IonRow, IonCol,
  IonSpinner, IonIcon, ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { bookmarkOutline, searchOutline, logOutOutline } from 'ionicons/icons';
import { MovieService } from '../../services/movie.service';
import { AuthService } from '../../services/auth.service';
import { Movie } from '../../models/movie.model';
import { TabBarComponent } from '../../components/tab-bar/tab-bar.component';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
  imports: [
    CommonModule, FormsModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonSearchbar, IonButton, IonGrid, IonRow, IonCol,
    IonSpinner, IonIcon, TabBarComponent
  ]
})
export class SearchPage {
  query = '';
  movies: Movie[] = [];
  isLoading = false;
  hasSearched = false;

  constructor(
    private movieService: MovieService,
    private authService: AuthService,
    private router: Router,
    private toastCtrl: ToastController
  ) {
    addIcons({ bookmarkOutline, searchOutline, logOutOutline });
  }

  onQueryChange() {
    if (!this.query.trim()) {
      this.movies = [];
      this.hasSearched = false;
    }
  }

  async search() {
    if (!this.query.trim()) {
      this.movies = [];
      this.hasSearched = false;
      return;
    }
    this.isLoading = true;
    this.hasSearched = true;
    this.movies = [];

    try {
      this.movies = await this.movieService.searchMovies(this.query);
    } catch {
      const toast = await this.toastCtrl.create({
        message: 'Failed to fetch movies. Check your connection.',
        duration: 3000,
        color: 'danger'
      });
      await toast.present();
    } finally {
      this.isLoading = false;
    }
  }

  async addToWatchlist(movie: Movie, event: Event) {
    event.stopPropagation();
    try {
      await this.movieService.addToWatchlist(movie);
      const toast = await this.toastCtrl.create({
        message: `"${movie.title}" added to Watchlist`,
        duration: 2000,
        color: 'success',
        position: 'bottom'
      });
      await toast.present();
    } catch {
      const toast = await this.toastCtrl.create({
        message: 'Already in your Watchlist.',
        duration: 2000,
        color: 'warning'
      });
      await toast.present();
    }
  }

  goToDetail(movie: Movie) {
    this.movieService.selectedMovie = movie;
    this.router.navigateByUrl('/movie-detail');
  }
}