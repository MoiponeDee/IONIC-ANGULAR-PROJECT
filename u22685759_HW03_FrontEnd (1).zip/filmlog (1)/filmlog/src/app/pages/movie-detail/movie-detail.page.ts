import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonButton, IonIcon, IonButtons, IonSpinner,
  ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  arrowBackOutline,
  addOutline,
  checkmarkOutline,
  refreshOutline
} from 'ionicons/icons';
import { MovieService } from '../../services/movie.service';
import { Movie } from '../../models/movie.model';

@Component({
  selector: 'app-movie-detail',
  templateUrl: './movie-detail.page.html',
  styleUrls: ['./movie-detail.page.scss'],
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonButton, IonIcon, IonButtons, IonSpinner
  ]
})
export class MovieDetailPage {
  movie: Movie | null = null;
  inWatchlist = false;
  isWatched = false;
  isLoading = true;

  constructor(
    private router: Router,
    private movieService: MovieService,
    private toastCtrl: ToastController
  ) {
    addIcons({
      arrowBackOutline,
      addOutline,
      checkmarkOutline,
      refreshOutline
    });
  }

  async ionViewWillEnter() {
    this.isLoading = true;
    this.movie = this.movieService.selectedMovie;

    if (this.movie) {

      if (!this.movie.actors && !this.movie.genre) {
        const full = await this.movieService.getMovieDetails(this.movie.title);

        if (full) {
          this.movie = {
            ...full,
            imdbId: this.movie.imdbId || full.imdbId
          };
        }
      }

     this.inWatchlist = await this.movieService.isInWatchlist(this.movie.imdbId);

      this.isWatched = await this.movieService.isWatched(this.movie.imdbId);
    }

    this.isLoading = false;
  }

  async addToWatchlist() {
    if (!this.movie) return;

    try {
      await this.movieService.addToWatchlist(this.movie);
      this.inWatchlist = true;

      const toast = await this.toastCtrl.create({
        message: 'Added to Watchlist',
        duration: 2000,
        color: 'success'
      });

      await toast.present();

    } catch {
      const toast = await this.toastCtrl.create({
        message: 'Already in Watchlist',
        duration: 2000,
        color: 'warning'
      });

      await toast.present();
    }
  }

  async markAsWatched() {
    if (!this.movie) return;

    const alreadyWatched = this.isWatched;

    await this.movieService.markAsWatched(this.movie);

    this.isWatched = true;
    this.inWatchlist = false;

    const toast = await this.toastCtrl.create({
      message: alreadyWatched
        ? 'Watched again! Count updated'
        : 'Moved to Watched List',
      duration: 2000,
      color: alreadyWatched ? 'success' : 'tertiary'
    });

    await toast.present();
  }

  goBack() {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      this.router.navigateByUrl('/search');
    }
  }
}