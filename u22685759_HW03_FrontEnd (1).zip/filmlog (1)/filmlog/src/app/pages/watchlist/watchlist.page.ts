import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import {
  IonHeader, IonToolbar, IonTitle, IonContent,
  IonGrid, IonRow, IonCol, IonButton, IonIcon,
  AlertController, ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { checkmarkCircleOutline, closeCircleOutline, bookmarkOutline } from 'ionicons/icons';
import { MovieService } from '../../services/movie.service';
import { WatchlistItem } from '../../models/movie.model';
import { TabBarComponent } from '../../components/tab-bar/tab-bar.component';

@Component({
  selector: 'app-watchlist',
  templateUrl: './watchlist.page.html',
  styleUrls: ['./watchlist.page.scss'],
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonGrid, IonRow, IonCol, IonButton, IonIcon,
    TabBarComponent
  ]
})
export class WatchlistPage {
  movies: WatchlistItem[] = [];

  constructor(
    private movieService: MovieService,
    private router: Router,
    private alertCtrl: AlertController,
    private toastCtrl: ToastController
  ) {
    addIcons({ checkmarkCircleOutline, closeCircleOutline, bookmarkOutline });
  }

  async ionViewWillEnter() {
    this.movies = await this.movieService.getWatchlist();
  }

  goToDetail(movie: WatchlistItem) {
    this.movieService.selectedMovie = movie;
    this.router.navigateByUrl('/movie-detail');
  }

  async remove(movie: WatchlistItem) {
    const alert = await this.alertCtrl.create({
      header: 'Remove Movie',
      message: `Remove "${movie.title}" from your Watchlist?`,
      buttons: [
        { text: 'Cancel', role: 'cancel' },
        {
          text: 'Remove', role: 'destructive',
          handler: async () => {
            await this.movieService.removeFromWatchlist(movie.id);
            this.movies = await this.movieService.getWatchlist();
            const toast = await this.toastCtrl.create({
              message: 'Removed from Watchlist',
              duration: 2000, color: 'warning'
            });
            await toast.present();
          }
        }
      ]
    });
    await alert.present();
  }

  async markWatched(movie: WatchlistItem, event: Event) {
    event.stopPropagation();
    await this.movieService.markAsWatched(movie);
    this.movies = await this.movieService.getWatchlist();
    const toast = await this.toastCtrl.create({
      message: `"${movie.title}" moved to Watched`,
      duration: 2000, color: 'success'
    });
    await toast.present();
  }
}