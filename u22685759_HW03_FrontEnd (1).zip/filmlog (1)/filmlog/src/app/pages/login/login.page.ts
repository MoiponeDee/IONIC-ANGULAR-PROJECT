import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonContent, IonItem, IonLabel, IonInput,
  IonButton, IonIcon, AlertController, LoadingController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { filmOutline } from 'ionicons/icons';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  imports: [
    CommonModule, FormsModule,
    IonContent, IonItem, IonLabel, IonInput, IonButton, IonIcon
  ]
})
export class LoginPage {
  isSignUp = false;
  firstName = '';
  email = '';
  password = '';

  constructor(
    private authService: AuthService,
    private router: Router,
    private alertCtrl: AlertController,
    private loadingCtrl: LoadingController
  ) {
    addIcons({ filmOutline });
  }

  toggleMode() {
    this.isSignUp = !this.isSignUp;
    this.firstName = '';
    this.email = '';
    this.password = '';
  }

  async submit() {
    if (!this.email || !this.password || (this.isSignUp && !this.firstName)) {
      const alert = await this.alertCtrl.create({
        header: 'Missing Fields',
        message: 'Please fill in all required fields.',
        buttons: ['OK']
      });
      await alert.present();
      return;
    }

    const loading = await this.loadingCtrl.create({ message: 'Please wait...' });
    await loading.present();

    try {
      if (this.isSignUp) {
        const registered = await this.authService.register(this.firstName, this.email, this.password);
        if (!registered) {
          await loading.dismiss();
          const alert = await this.alertCtrl.create({
            header: 'Account Exists',
            message: 'An account with this email already exists.',
            buttons: ['OK']
          });
          await alert.present();
          return;
        }
      
        await this.authService.login(this.email, this.password);
        await loading.dismiss();
      } else {
        const success = await this.authService.login(this.email, this.password);
        await loading.dismiss();
        if (!success) {
          const alert = await this.alertCtrl.create({
            header: 'Login Failed',
            message: 'Invalid email or password.',
            buttons: ['OK']
          });
          await alert.present();
          return;
        }
      }
      this.router.navigateByUrl('/search', { replaceUrl: true });
    } catch (e: any) {
      await loading.dismiss();
      const alert = await this.alertCtrl.create({
        header: 'Error',
        message: e?.error?.message || 'Something went wrong. Please try again.',
        buttons: ['OK']
      });
      await alert.present();
    }
  }
}
