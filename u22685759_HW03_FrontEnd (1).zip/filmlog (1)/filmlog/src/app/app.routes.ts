import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.page').then(m => m.LoginPage)
  },
  {
    path: 'search',
    canActivate: [authGuard],
    loadComponent: () => import('./pages/search/search.page').then(m => m.SearchPage)
  },
  {
    path: 'watchlist',
    canActivate: [authGuard],
    loadComponent: () => import('./pages/watchlist/watchlist.page').then(m => m.WatchlistPage)
  },
  {
    path: 'watched',
    canActivate: [authGuard],
    loadComponent: () => import('./pages/watched/watched.page').then(m => m.WatchedPage)
  },
  {
    path: 'movie-detail',
    canActivate: [authGuard],
    loadComponent: () => import('./pages/movie-detail/movie-detail.page').then(m => m.MovieDetailPage)
  },
  {
    path: 'reports',
    canActivate: [authGuard],
    loadComponent: () => import('./reports/reports.component').then(m => m.ReportsComponent)
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  }
];
