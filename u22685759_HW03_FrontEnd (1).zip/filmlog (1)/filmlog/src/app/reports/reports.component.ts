import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonHeader, IonToolbar, IonTitle, IonContent, IonSpinner
} from '@ionic/angular/standalone';
import { MovieService } from '../services/movie.service';
import { WatchedItem } from '../models/movie.model';
import { TabBarComponent } from '../components/tab-bar/tab-bar.component';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss'],
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonContent, IonSpinner,
    TabBarComponent
  ]
})
export class ReportsComponent {
movies: WatchedItem[] = [];
  isLoading = true;

  
  genreData: { genre: string; count: number; percentage: number; color: string }[] = [];

 
  topWatched: { title: string; timesWatched: number }[] = [];

 
  tableData: WatchedItem[] = [];

private readonly pieColors = [
  '#6ecbff', // sky blue
  '#ff8a65', // soft coral
  '#66bb6a', // green
  '#ba68c8', // purple
  '#ffd54f', // warm yellow
  '#26c6da'  // cyan
];

  constructor(private movieService: MovieService) {}

  async ionViewWillEnter() {
    this.isLoading = true;
    this.movies = await this.movieService.getWatchedList();
    this.buildGenreChart();
    this.buildBarChart();
    this.buildTable();
    this.isLoading = false;
  }

  private buildGenreChart() {
    const genreCount: Record<string, number> = {};
    for (const movie of this.movies) {
      if (!movie.genre) continue;
      for (const g of movie.genre.split(',').map(s => s.trim()).filter(Boolean)) {
        genreCount[g] = (genreCount[g] || 0) + Math.max(movie.timesWatched, 1);
      }
    }
    const sorted = Object.entries(genreCount)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 6);
    const total = sorted.reduce((sum, [, v]) => sum + v, 0);
    this.genreData = sorted.map(([genre, count], i) => ({
      genre,
      count,
      percentage: total > 0 ? Math.round((count / total) * 100) : 0,
      color: this.pieColors[i]
    }));
  }

  private buildBarChart() {
    this.topWatched = [...this.movies]
      .sort((a, b) => b.timesWatched - a.timesWatched)
      .slice(0, 8)
      .map(m => ({
        title: m.title.length > 16 ? m.title.slice(0, 16) + '…' : m.title,
        timesWatched: m.timesWatched
      }));
  }

  private buildTable() {
    this.tableData = [...this.movies].sort((a, b) => b.timesWatched - a.timesWatched);
  }

  get maxTimesWatched(): number {
    return Math.max(...this.topWatched.map(m => m.timesWatched), 1);
  }

  get totalWatched(): number {
    return this.movies.reduce((sum, m) => sum + Math.max(m.timesWatched, 1), 0);
  }

  get uniqueGenres(): number {
    const genres = new Set<string>();
    this.movies.forEach(m =>
      m.genre?.split(',').forEach(g => { if (g.trim()) genres.add(g.trim()); })
    );
    return genres.size;
  }

  get pieSlices(): { path: string; color: string }[] {
    if (!this.genreData.length) return [];
    const total = this.genreData.reduce((s, g) => s + g.count, 0);
    if (total === 0) return [];

    const cx = 100, cy = 100, r = 90;
    let startAngle = -Math.PI / 2;

    return this.genreData.map(g => {
      const angle    = (g.count / total) * 2 * Math.PI;
      const endAngle = startAngle + angle;
      const x1 = cx + r * Math.cos(startAngle);
      const y1 = cy + r * Math.sin(startAngle);
      const x2 = cx + r * Math.cos(endAngle);
      const y2 = cy + r * Math.sin(endAngle);
      const large = angle > Math.PI ? 1 : 0;
      const path = `M${cx},${cy} L${x1.toFixed(2)},${y1.toFixed(2)} A${r},${r} 0 ${large},1 ${x2.toFixed(2)},${y2.toFixed(2)} Z`;
      startAngle = endAngle;
      return { path, color: g.color };
    });
  }

}
