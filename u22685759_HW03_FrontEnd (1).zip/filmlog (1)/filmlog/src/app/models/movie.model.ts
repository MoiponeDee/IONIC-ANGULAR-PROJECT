export interface Movie {
  imdbId: string;
  title: string;
  year: string;
  poster: string;
  actors: string;
  genre: string;
  plot?: string;
}

export interface WatchlistItem {
  id: number;
  imdbId: string;
  title: string;
  year: string;
  poster: string;
  actors: string;
  genre: string;
  addedAt?: string;
}

export interface WatchedItem {
  id: number;
  imdbId: string;
  title: string;
  year: string;
  poster: string;
  actors: string;
  genre: string;
  timesWatched: number;
  watchedAt?: string;
}

export interface User {
  firstName: string;
  email: string;
  password: string;
}