import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private baseUrl = 'http://localhost:5242/api/user';
  private readonly TOKEN_KEY = 'token';

  constructor(private http: HttpClient) {}

  async register(firstName: string, email: string, password: string): Promise<boolean> {
    try {
      await firstValueFrom(
        this.http.post(`${this.baseUrl}/register`, {
           firstName: firstName,
    emailaddress: email,
    password: password
        })
      );
      return true;
    } catch (err: any) {
      
      if (err?.status === 403) return false;
      throw err;
    }
  }

  async login(email: string, password: string): Promise<boolean> {
    try {
      const response: any = await firstValueFrom(
        this.http.post(`${this.baseUrl}/login`, {
          emailaddress: email,
          password
        })
      );
      if (response?.token) {
        localStorage.setItem(this.TOKEN_KEY, response.token);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }
}
