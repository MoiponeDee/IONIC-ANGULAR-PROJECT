import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { Movie, WatchlistItem, WatchedItem } from '../models/movie.model';

@Injectable({ providedIn: 'root' })
export class MovieService {
  private baseUrl = 'http://localhost:5242/api';
  selectedMovie: Movie | null = null;

  constructor(private http: HttpClient) {}


  clearState(): void {
    this.selectedMovie = null;
  }


  async searchMovies(query: string): Promise<Movie[]> {
    const response: any = await firstValueFrom(
      this.http.get(`${this.baseUrl}/movies/search?t=${encodeURIComponent(query)}`)
    );

    if (response?.Search) {
      return response.Search.map((item: any) => ({
        imdbId: item.imdbID || item.imdbId || '',
        title: item.Title || item.title || '',
        year: item.Year || item.year || '',
        poster: (item.Poster && item.Poster !== 'N/A') ? item.Poster : '',
        actors: item.Actors || '',
        genre: item.Genre || '',
        plot: item.Plot || ''
      }));
    }

    if (response?.Title) {
      return [{
        imdbId: response.imdbID || '',
        title: response.Title || '',
        year: response.Year || '',
        poster: (response.Poster && response.Poster !== 'N/A') ? response.Poster : '',
        actors: response.Actors || '',
        genre: response.Genre || '',
        plot: response.Plot || ''
      }];
    }

    return [];
  }

  async getMovieDetails(title: string): Promise<Movie | null> {
    try {
      const response: any = await firstValueFrom(
        this.http.get(`${this.baseUrl}/movies/details?t=${encodeURIComponent(title)}`)
      );

      if (response?.Title) {
        return {
          imdbId: response.imdbID || '',
          title: response.Title || '',
          year: response.Year || '',
          poster: (response.Poster && response.Poster !== 'N/A') ? response.Poster : '',
          actors: response.Actors || '',
          genre: response.Genre || '',
          plot: response.Plot || ''
        };
      }

      return null;
    } catch {
      return null;
    }
  }


async addToWatchlist(movie: Movie): Promise<void> {
  if (!movie.imdbId) throw new Error('Movie has no imdbId');

  let genre = movie.genre || '';

  if (!genre) {
    const details = await this.getMovieDetails(movie.title);
    genre = details?.genre || 'Unknown';
  }

  await firstValueFrom(
    this.http.post(`${this.baseUrl}/watchlist`, {
      imdbId: movie.imdbId,
      title: movie.title,
      year: movie.year,
      poster: movie.poster,
      actors: movie.actors,
      genre: genre
    })
  );
}

  async getWatchedList(): Promise<WatchedItem[]> {
    try {
      return await firstValueFrom(
        this.http.get<WatchedItem[]>(`${this.baseUrl}/watched`)
      );
    } catch {
      return [];
    }
  }

 async markAsWatched(movie: Movie | WatchlistItem): Promise<void> {
  if (!movie.imdbId) throw new Error('Movie has no imdbId');

  let genre = movie.genre || '';

  if (!genre) {
    const details = await this.getMovieDetails(movie.title);
    genre = details?.genre || 'Unknown';
  }

  await firstValueFrom(
    this.http.post(`${this.baseUrl}/watched`, {
      imdbId: movie.imdbId,
      title: movie.title,
      year: movie.year,
      poster: movie.poster,
      actors: movie.actors,
      genre: genre
    })
  );
}

  async incrementTimesWatched(id: number): Promise<void> {
    await firstValueFrom(
      this.http.put(`${this.baseUrl}/watched/${id}`, {})
    );
  }

async getWatchlist(): Promise<WatchlistItem[]> {
  try {
    const data: any[] = await firstValueFrom(
      this.http.get<any[]>(`${this.baseUrl}/watchlist`)
    );

    return data.map(movie => ({
      id: movie.id ?? movie.Id,
      imdbId: movie.imdbId ?? movie.ImdbId,
      title: movie.title ?? movie.Title,
      year: movie.year ?? movie.Year,
      poster: movie.poster ?? movie.Poster,
      actors: movie.actors ?? movie.Actors,
      genre: movie.genre ?? movie.Genre
    }));
  } catch {
    return [];
  }
}

  async removeFromWatchedList(id: number): Promise<void> {
  await firstValueFrom(
    this.http.delete(`${this.baseUrl}/watched/${id}`,
      {
        responseType: 'text'
      }
    )
  );
}

async removeFromWatchlist(id: number): Promise<void> {
  await firstValueFrom(
    this.http.delete(`${this.baseUrl}/watchlist/${id}`, {
      responseType: 'text'
    })
  );
}

async resetTimesWatched(id: number): Promise<void> {
  await firstValueFrom(
    this.http.post(`${this.baseUrl}/watched/reset/${id}`, {}, {
      responseType: 'text'
    })
  );
}

  async isInWatchlist(imdbId: string): Promise<boolean> {
    const list = await this.getWatchlist();
    return list.some(m => m.imdbId === imdbId);
  }

  async isWatched(imdbId: string): Promise<boolean> {
    const list = await this.getWatchedList();
    return list.some(m => m.imdbId === imdbId);
  }
}